#!/bin/bash

 
sqoop job --meta-connect jdbc:hsqldb:hsql://localhost:16000/sqoop \
--create cdw_sapp_creditcard_inc_job \
-- import --connect jdbc:mysql://localhost/CDW_SAPP \
--query 'SELECT TRANSACTION_ID, CREDIT_CARD_NO CUST_CC_NO,CONCAT(YEAR, case when LENGTH(MONTH) = 2 then MONTH else CONCAT("0",MONTH) END, CASE WHEN LENGTH(DAY) = 2 then DAY else CONCAT("0",DAY) end) TIMEID,
CUST_SSN, BRANCH_CODE, TRANSACTION_TYPE, TRANSACTION_VALUE FROM CDW_SAPP_CREDITCARD WHERE $CONDITIONS' \
--driver com.mysql.jdbc.Driver \
--target-dir /user/maria_dev/Credit_Card_System/CDW_SAPP_CREDITCARD \
--incremental append \
-check-column TRANSACTION_ID \
--last-value 0 \
-m 1;


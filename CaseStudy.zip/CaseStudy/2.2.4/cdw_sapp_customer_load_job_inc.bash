#!/bin/bash

sqoop job --meta-connect jdbc:hsqldb:hsql://localhost:16000/sqoop \
--create cdw_sapp_customer_inc_job \
-- import --connect jdbc:mysql://localhost/CDW_SAPP \
--query 'SELECT cast(SSN as UNSIGNED) CUST_SSN, CONCAT(UCASE(SUBSTRING(FIRST_NAME, 1, 1)),LOWER(SUBSTRING(FIRST_NAME, 2))) CUST_F_NAME, lcase(MIDDLE_NAME)CUST_M_NAME,
CONCAT(UCASE(SUBSTRING(LAST_NAME, 1, 1)),LOWER(SUBSTRING(LAST_NAME, 2))) CUST_L_NAME,CREDIT_CARD_NO CUST_CC_NO,CONCAT(STREET_NAME,"-",APT_NO) CUST_STREET, CUST_CITY, CUST_STATE, CUST_COUNTRY, 
cast(CUST_ZIP as UNSIGNED) CUST_ZIP,CONCAT(LEFT(CUST_PHONE,3) , "-", right(CUST_PHONE, 4)) CUST_PHONE, CUST_EMAIL, LAST_UPDATED FROM CDW_SAPP.CDW_SAPP_CUSTOMER WHERE $CONDITIONS' \
--driver com.mysql.jdbc.Driver \
--target-dir /user/maria_dev/Credit_Card_System/CDW_SAPP_CUSTOMER \
--incremental lastmodified \
--check-column LAST_UPDATED \
--merge-key=CUST_SSN \
-m 1;

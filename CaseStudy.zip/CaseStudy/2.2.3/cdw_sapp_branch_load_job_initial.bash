#!/bin/bash 

sqoop job --meta-connect jdbc:hsqldb:hsql://localhost:16000/sqoop \
--create cdw_sapp_branch_initial_job \
-- import --connect jdbc:mysql://localhost/CDW_SAPP \
--query "SELECT BRANCH_CODE,BRANCH_NAME,BRANCH_STREET,BRANCH_CITY,BRANCH_STATE, \
case when BRANCH_ZIP is null then '999999' else BRANCH_ZIP end BRANCH_ZIP, \
CONCAT('(', left(BRANCH_PHONE,3), ')', substring(BRANCH_PHONE, 4,3), '-', \
right(BRANCH_PHONE, 4)) BRANCH_PHONE, LAST_UPDATED \
FROM CDW_SAPP.CDW_SAPP_BRANCH WHERE \$CONDITIONS" \
--driver com.mysql.jdbc.Driver \
--target-dir /user/maria_dev/Credit_Card_System/CDW_SAPP_BRANCH \
--as-textfile \
-m 1;


